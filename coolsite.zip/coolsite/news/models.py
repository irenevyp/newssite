from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User

# Create your models here.
class News(models.Model):
    title = models.CharField(max_length=300, verbose_name= 'Заголовок новости')
#    slug = models.SlugField(max_length=255,unique=True,db_index=True,verbose_name='URL')
    post = models.TextField(blank = True, verbose_name= 'Содержание новости')
    date = models.DateField(verbose_name= 'Дата публикации')
    link = models.URLField()
    name = models.CharField(max_length=100)
    cat= models.ForeignKey('Category', on_delete = models.PROTECT,null = True, verbose_name= 'Автор публикации')

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('post', kwargs = {'pk': self.pk})

    class Meta:
        verbose_name = 'Новости сельского хозяйства'
        verbose_name_plural = 'Новости сельского хозяйства'
        ordering = ['-date']


class Category(models.Model):
    name = models.CharField(max_length=100, db_index= True, verbose_name= 'Автор публикации')
#    slug = models.SlugField(max_length=255,unique=True,db_index=True,verbose_name='URL')

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('category', kwargs = {'cat_id': self.pk})

    class Meta:
        verbose_name = 'Автор публикации'
        verbose_name_plural = 'Авторы публикаций'
        ordering = ['id', ]