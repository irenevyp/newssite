from django.contrib.auth import logout, login
from django.contrib.auth.models import AnonymousUser
from django.contrib.auth.views import LoginView, LogoutView
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseNotFound, Http404
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, FormView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm

from .models import *
from .forms import *
from .utils import *



class NewsHome(DataMixin,ListView):
    paginate_by = 10
    model = News
    template_name = 'news/index.html'
    context_object_name = 'posts'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title = 'Главная страница')
        return dict(list(context.items())+list(c_def.items()))

    def get_queryset(self):
        return News.objects.select_related('cat')



class RegisterUser(DataMixin, CreateView):
    form_class = RegisterUserForm
    template_name = 'news/register.html'
    success_url = reverse_lazy('login')

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title="Регистрация")
        return dict(list(context.items()) + list(c_def.items()))

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        return redirect('home')


class LoginUser(DataMixin, LoginView):
    form_class = LoginUserForm
    template_name = 'news/login.html'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title="Авторизация")
        return dict(list(context.items()) + list(c_def.items()))

    def get_success_url(self):
        return reverse_lazy('home')





def about(request):
    return render(request,'news/about.html', {'menu': menu, 'title': 'О сайте'})


class AddPage(LoginRequiredMixin, DataMixin, CreateView):
    form_class = AddPostForm
    template_name = 'news/addpage.html'
    success_url = reverse_lazy('home')
    login_url =reverse_lazy('home')

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title='Добавление статьи')
        return dict(list(context.items())+list(c_def.items()))



class ContactFormView(DataMixin, FormView):
    form_class = ContactForm
    template_name = 'news/contact.html'
    success_url = reverse_lazy('home')

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title="Обратная связь")
        return dict(list(context.items()) + list(c_def.items()))

    def form_valid(self, form):
        print(form.cleaned_data)
        return redirect('home')

class ShowPost(DataMixin, DetailView):
    model = News
    template_name = 'news/post.html'
    pk_url_kwarg = 'pk'
    context_object_name = 'post'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title=context['post'])
        return dict(list(context.items()) + list(c_def.items()))




class NewsCategory(DataMixin, ListView):
    paginate_by = 10
    model = News
    template_name = 'news/index.html'
    context_object_name = 'posts'

    def get_queryset(self):
        c = News.objects.filter(cat__id = self.kwargs['cat_id']).select_related('cat')
        c = c.order_by('-date')
        return c #News.objects.filter(cat__id = self.kwargs['cat_id']).select_related('cat')


    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
#        c = Category.objects.get(cat__id =self.kwargs['cat_id'])
#        c_def = self.get_user_context(title='Категория -' + str(c.name),cat_selected=c.pk)
        c_def = self.get_user_context(title='Категория -' + str(context['posts'][0].cat),cat_selected=context['posts'][0].cat_id)
        return dict(list(context.items()) + list(c_def.items()))



def categories(request,cat):
    return HttpResponse(f'<h1> News on categories </h1> <p>{cat}</p>')

def archive(request,year):
    if int(year) > 2022:
        return redirect('home')
    return HttpResponse(f'<h1> News on years </h1> <p>{year}</p>')

def pageNotFound(request, exception):
    return HttpResponseNotFound(f'<h1> Страница не найдена </h1>')

def logout_user(request):
    logout(request)
    return redirect('home')