from django.urls import path, re_path
from .views import *





urlpatterns = [
    path('', NewsHome.as_view(), name = 'home'), # http://127.0.0.1:8000
    path('cats/<slug:cat>/', categories), # http://127.0.0.1:8000/cats/
    re_path(r'^archive/(?P<year>[0-9]{4})/', archive),
    path('about/', about, name = 'about'), # http://127.0.0.1:8000
    path('addpage/', AddPage.as_view(), name = 'addpage'),
    path('contact/', ContactFormView.as_view(), name='contact'),
    path('login/', LoginUser.as_view(), name='login'),
    path('logout/', logout_user, name='logout'),
    path('register/', RegisterUser.as_view(), name = 'register'),
    path('post/<int:pk>', ShowPost.as_view(), name = 'post'),
    path('category/<int:cat_id>', NewsCategory.as_view(), name = 'category'),



]
