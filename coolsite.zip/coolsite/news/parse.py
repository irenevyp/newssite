import requests
from bs4 import BeautifulSoup
import sqlite3 as sq

URL_VNIALMI = 'https://vfanc.ru/category/novosti-czentra/'
URL_OREL = 'https://apk.orel-region.ru/'
HEADERS = ''
news = []


def date_to_date(a):
    d = {'января': '01',
         'февраля': '02',
         'марта': '03',
         'апреля': '04',
         'мая': '05',
         'июня': '06',
         'июля': '07',
         'августа': '08',
         'сентября': '09',
         'октября': '10',
         'ноября': '11',
         'декабря': '12',
         }
    if a.find('г.') > 0:
        a1 = a[:a.find('г.')].split()
    else:
        a1 = a.split()
    if a1[1][-1] == ',':
        a1[1] = a1[1][:-1]
    if len(a1[0]) < 2:
        a1[0] = '0' + a1[0]
    #        print('a1[0]=', a1[0])
    return a1[2] + '-' + d[a1[1]] + '-' + a1[0]


class News:
    def __init__(self, title, post, date, link, name, cat):
        self.title = title
        self.post = post
        self.date = date
        self.link = link
        self.name = name
        self.cat = cat

    def news_print(self):
        print('Новости из ', self.name)
        print('Название новости ', self.title, 'Дата ', self.date)
        print('Содержание новости ', self.post)
        print('Ссылка на новость ', self.link)
        print('Категория новости ', self.cat)


def to_sql(title, post, date, link, name, cat):
    with sq.connect('so.sqlite3') as con:
        cur = con.cursor()

        cur.execute(""" CREATE TABLE IF NOT EXISTS  articles(
        title TEXT,
        post TEXT,
        date DATE,
        link TEXT,

        name text,
        cat int
        )
        """)

        print(title, post, date, link, name, cat)
        info = cur.execute('SELECT * FROM articles WHERE link == link')
        if info.fetchone() is None:
            sql = """
                    INSERT OR IGNORE INTO  articles (title,post,date,link, name,cat)
                    VALUES (?, ?, ?, ?, ?,?)
                    """

            cur.execute(sql, (title, post, date, link, name, cat))
            print("записано")
            con.commit()


def get_html(url, params=None):
    r = requests.get(url, params=params)
    return r


def get_content_vnialmi(html):
    soup = BeautifulSoup(html, 'html.parser')
    hr = []
    hd = []
    ht = []
    hl = []
    for el in soup.find_all('h2', class_='post-title'):
        hl.append(el.find('a').get('href'))
        hr.append(el)

    for el in soup.find_all('div', class_='post-date'):
        hd.append(el)
    for el in soup.find_all('div', class_='post-excerpt'):
        ht.append(el)
    s = []
    for el in hr:
        s.append(el.get_text().replace('\n', ''))
    #    print(s)

    print(hr)
    print(hd)
    print(hl)
    print('link=', hr[2].find('a').get('href'))

    print(hr[2].get_text())
    print(hd[2].get_text())
    print(ht[2].get_text())
    cat = 2
    for i in range(len(hr)):
        news.append(News(s[i], str(ht[i].get_text().replace('\n', '')), date_to_date(hd[i].get_text()),
                         hr[i].find('a').get('href'), 'ФНЦ агроэкологии РАН', cat))


# получение данных парсинга с сайти депармтамента сельского хозяйства Орловской области
def get_content_orel(html):
    name = 'Департамент сельского хозяйства Орловской области'

    hd = []  # дата новости
    ht = []  # название новости
    hl = []  # ссылка на новость
    hp = []  # содержание новости

    soup = BeautifulSoup(html, 'html.parser')
    el = soup.find_all(class_='infoBlock')  # выбор всех новостей на сайте
    for e in el:
        da = e.find(class_='infoBlockDate').text.split(',')  # выбор даты
        hd.append(da[0][3:])  # занесение непреобразованной  даты в массив дат
        ht.append(e.find('h2').string)  # занесение названия новости в массив названий
        u = e.find_all('a')
        for uu in u:
            if 'Читать' in uu.string:
                uu = str(uu)  # выбор ссылки на новость в усеченном виде
                b = uu.find('"')
                link1 = uu[b + 3:]
                b = link1.find('"')
                link1 = link1[:b]
                hl.append(
                    URL_OREL + link1)  # формирование ссылки на новость в полном виде и занесение ее в массив ссылок
                hp.append(full_text_orel(
                    URL_OREL + link1))  # переход по ссылке и формирование содержания новости. Добавление содержания в массив

    cat = 1
    for i in range(len(ht)):
        print('i=', i)
        news.append(News(ht[i], hp[i], date_to_date(hd[i]), hl[i], name, cat))


def full_text_orel(url):
    html = get_html(url)
    soup = BeautifulSoup(html.text, 'html.parser')
    if len(soup.find_all('table')) == 0:  # если новость не является таблицей
        el = soup.find_all('div', id='main')  # выбор новости
        res = ''
        for el1 in el:
            e = el1.find_all('p')
            for g in e:
                res = res + g.text  # формирование текста новости
    else:
        res = 'Таблица'  # если таблица
    return res


def parse_vnialmi():
    for i in range(1, 16):
        html = get_html(URL_VNIALMI + 'page/' + str(i) + '/')
        if html.status_code == 200:
            get_content_vnialmi(html.text)
    else:
        print('Error')


def parse_orel():  # парсинг сайта департамента сх орловской области
    for i in range(1, 61):  # i - номер страницы
        print('page=', i)
        html = get_html(URL_OREL + 'index.php?cont=2&page=' + str(i))
        if html.status_code == 200:  # если ответ В ПОРЯДКЕ
            get_content_orel(html.text)  # переход на парсинг соответствующей страницы
        else:
            print('Error')  # если ответ  НЕ В ПОРЯДКЕ


# parse_vnialmi()
parse_orel()
for i in range(len(news)):
    news[i].news_print()
    to_sql(news[i].title, news[i].post, news[i].date, news[i].link, news[i].name, news[i].cat)